package com.mondego.models;

public interface IListener {
	
}
